import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _49b1a294 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _41313be8 = () => interopDefault(import('../pages/home/index' /* webpackChunkName: "" */))
const _f2f09a82 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _46e66102 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _464d310d = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _3de2c8d7 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _f27f81ae = () => interopDefault(import('../pages/posts' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _49b1a294,
    children: [{
      path: "/",
      component: _41313be8,
      name: "home"
    }, {
      path: "/login",
      component: _f2f09a82,
      name: "login"
    }, {
      path: "/register",
      component: _f2f09a82,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _46e66102,
      name: "profile"
    }, {
      path: "/settings",
      component: _464d310d,
      name: "settings"
    }, {
      path: "/editor",
      component: _3de2c8d7,
      name: "editor"
    }, {
      path: "/posts/:slug",
      component: _f27f81ae,
      name: "posts"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
